import Foundation

class Fecha {
    private var dia: Int
    private var mes: Int
    private var anio: Int

    init() {
        self.dia = 1
        self.mes = 1
        self.anio = 2000
    }

    init(dia: Int, mes: Int, anio: Int) {
        self.dia = dia
        self.mes = mes
        self.anio = anio
        setDia(dia)
        setMes(mes)
        setAnio(anio)
    }

    func getDia() -> Int {
        return dia
    }

    func setDia(_ dia: Int) {
        if dia > 0 && dia < 32 {
            self.dia = dia
        } else {
            print("Día no válido")
        }
    }

    func getMes() -> Int {
        return mes
    }

    func setMes(_ mes: Int) {
        if mes > 0 && mes < 13 {
            self.mes = mes
        } else {
            print("Mes no válido")
        }
    }

    func getAnio() -> Int {
        return anio
    }

    func setAnio(_ anio: Int) {
        if anio > 0 {
            self.anio = anio
        } else {
            print("El año no puede ser negativo")
        }
    }
}

class Persona {
    private var nombre: String
    private var apellido: String
    private var fNacimiento: Fecha

    init() {
        self.nombre = ""
        self.apellido = ""
        self.fNacimiento = Fecha()
    }

    init(nombre: String, apellido: String, fNacimiento: Fecha) {
        self.nombre = nombre
        self.apellido = apellido
        self.fNacimiento = fNacimiento
    }

    func getNombre() -> String {
        return nombre
    }

    func setNombre(_ nombre: String) {
        self.nombre = nombre
    }

    func getApellido() -> String {
        return apellido
    }

    func setApellido(_ apellido: String) {
        self.apellido = apellido
    }

    func getFNacimiento() -> Fecha {
        return fNacimiento
    }

    func setFNacimiento(_ fNacimiento: Fecha) {
        self.fNacimiento = fNacimiento
    }
}

class PruebaPersona {
    static func main() {
        let per1 = Persona()
        let nac = Fecha()

        per1.setNombre("Juan")
        per1.setApellido("Perez")
        nac.setDia(15)
        nac.setMes(8)
        nac.setAnio(1950)
        per1.setFNacimiento(nac)

        print("Nombre: \(per1.getNombre())")
        print("Apellido: \(per1.getApellido())")
        print("Fecha Nacimiento: \(per1.getFNacimiento().getDia())/\(per1.getFNacimiento().getMes())/\(per1.getFNacimiento().getAnio())")
    }
}

// Llamada a la función main
PruebaPersona.main()
