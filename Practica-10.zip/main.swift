import Foundation

class Poligono {
    func area() -> Double {
        return 0.0
    }

    func perimetro() -> Double {
        return 0.0
    }

    func toString() -> String {
        return "Poligono"
    }
}

class Cuadrilatero: Poligono {
    private var alfa: Int
    private var beta: Int
    private var a: Float
    private var b: Float
    private var base: Float
    private var altura: Float

    init(alfa: Int, beta: Int, a: Float, b: Float, base: Float, altura: Float) {
        self.alfa = alfa
        self.beta = beta
        self.a = a
        self.b = b
        self.base = base
        self.altura = altura
        super.init()
    }

    override func toString() -> String {
        return "Cuadrilatero"
    }

    func tieneLadosParalelos() -> Bool {
        return true
    }
}

class Triangulo: Poligono {
    private var sideA: Float
    private var sideB: Float
    private var sideC: Float

    init(sideA: Float, sideB: Float, sideC: Float) {
        self.sideA = sideA
        self.sideB = sideB
        self.sideC = sideC
        super.init()
    }

    override func toString() -> String {
        return "Triangulo"
    }

    func tieneLadosParalelos() -> Bool {
        return false
    }
}

class PruebaFigurasGeometricas {
    static func main() {
        let poligono = Poligono()
        let objeto: AnyObject = poligono
        print(objeto)

        let triangulo = Triangulo(sideA: 3.0, sideB: 4.0, sideC: 5.0)
        print(triangulo)

        let cuadrilatero = Cuadrilatero(alfa: 90, beta: 90, a: 3.0, b: 4.0, base: 5.0, altura: 6.0)
        print(cuadrilatero)
    }
}

// Llamada a la función main
PruebaFigurasGeometricas.main()
