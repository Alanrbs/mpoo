class Empleado {
    private var nombre: String = ""
    private var numEmpleado: Int = 0
    private var sueldo: Int = 0

    func setNombre(_ nombre: String) {
        self.nombre = nombre
    }

    func getNombre() -> String {
        return self.nombre
    }

    func setNumEmpleado(_ numEmpleado: Int) {
        self.numEmpleado = numEmpleado
    }

    func getNumEmpleado() -> Int {
        return self.numEmpleado
    }

    func setSueldo(_ sueldo: Int) {
        if sueldo >= 0 {
            self.sueldo = sueldo
        }
    }

    func getSueldo() -> Int {
        return self.sueldo
    }

    func aumentarSueldo(_ porcentaje: Int) {
        sueldo += Int(Double(sueldo) * Double(porcentaje) / 100.0)
    }
}
class Gerente: Empleado {
    private var presupuesto: Int = 0

    func setPresupuesto(_ presupuesto: Int) {
        self.presupuesto = presupuesto
    }

    func getPresupuesto() -> Int {
        return self.presupuesto
    }

    func asignarPresupuesto(_ p: Int) {
        presupuesto = p
    }
}
class PruebaEmpleado {
  static func main() {
      let gerente = Gerente()
      gerente.setNombre("Luis Aguilar")
      gerente.setNumEmpleado(8524)
      gerente.setSueldo(16000)

      print("Nombre: \(gerente.getNombre())")
      print("Número de empleado: \(gerente.getNumEmpleado())")
      print("Sueldo: \(gerente.getSueldo())")

      gerente.aumentarSueldo(10)
      print("Nuevo sueldo: \(gerente.getSueldo())")

      gerente.setPresupuesto(50000)
      print("Presupuesto: \(gerente.getPresupuesto())")

      gerente.asignarPresupuesto(65000)
      print("Nuevo presupuesto: \(gerente.getPresupuesto())")
  }
}

// Llamada a la función main
PruebaEmpleado.main()
